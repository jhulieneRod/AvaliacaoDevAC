<?php
    require_once 'conexao.php';
    if(isset($_POST['botao'])){
        $botao = $_POST['botao'];
    }else if(isset($_GET['botao'])){
        $botao = $_GET['botao'];
    }else{
       $botao = '';
    }
    $produto = new Produto;
    if($botao == 'Inserir'){
        $produto->getValores();
        $produto->insereProduto();
    }else if ($botao == 'Alterar'){
        $codigo = $_POST['codigo'];
        $produto->alteraProduto($codigo);
    }else if($botao == 'Deletar'){
        $codigo = $_GET['codigo'];
        $produto->deletaProduto($codigo);
    }else if($botao == 'Restaurar'){
        $codigo = $_GET['codigo'];
        $produto->restaurarProduto($codigo);
    }else{
        if(isset($_POST['codigo'])){
            $codigo = $_POST['codigo'];
        }
    }


    class Produto {
        private $descricao;
        private $estoque;
        private $codigoBarras;
        private $valorUnitario;

        function setValores() {
            $this->descricao     = $_POST["descricao"];
            $this->estoque       = $_POST["estoque"];
            $this->codigoBarras  = $_POST["codigoBarras"];
            $this->valorUnitario = $_POST["valorUnitario"];
        }

        public function getDescricao(){
            return $this->descricao;
        }

        public function getEstoque(){
            return $this->estoque;
        }

        public function getCodigoBarras(){
            return $this->codigoBarras;
        }

        public function getValorUnitario(){
            return $this->valorUnitario;
        }

        public function setProduto($codigo){
            $sql = 'SELECT * FROM produtos where codigo = '.$codigo;
            $con = new Conexao;
            $con->setConexao();
            $rQry = mysqli_query($con->conexao, $sql);
            while($Dados = mysqli_fetch_array($rQry)){
                $this->descricao     = $Dados[1];
                $this->estoque       = $Dados[2];
                $this->codigoBarras  = $Dados[3];
                $this->valorUnitario = $Dados[4];
            }
        }

        public function insereProduto(){
            $sql = 'INSERT INTO `produtos`(`descricao`, `estoque`, `codigoBarras`, `valorUnitario`, `excluido`) 
                    VALUES ("'.$this->getDescricao().'",'.$this->getEstoque().',"'.$this->getCodigoBarras().'",'.$this->getValorUnitario().', 0)';
            $con = new Conexao;
            $con->setConexao();
            $result = $con->query($sql);
            header('Location: form-produto-edit.php');
        }

        public function alteraProduto($codigo){
            $produto->setProduto($codigo);
            $sql = 'UPDATE `produtos` SET 
                    `descricao`="'.$this->getDescricao().'",
                    `estoque`='.$this->getEstoque().',
                    `codigoBarras`="'.$this->getCodigoBarras().'",
                    `valorUnitario`='.$this->getValorUnitario().'
                    WHERE codigo = '.$codigo;
            $con = new Conexao;
            $con->setConexao();
            $result = $con->query($sql);
            header('Location: produtos.php');
        }

        public function deletaProduto($codigo){
            $sql = 'UPDATE `produtos` SET 
                    `excluido`= 1
                    WHERE codigo = '.$codigo;
            $con = new Conexao;
            $con->setConexao();
            $result = $con->query($sql);
            header('Location: produtos.php');
        }

        public function restaurarProduto($codigo){
            $sql = 'UPDATE `produtos` SET 
                    `excluido`= 0
                    WHERE codigo = '.$codigo;
            $con = new Conexao;
            $con->setConexao();
            $result = $con->query($sql);
            header('Location: produtos.php');
        }
    }
?>