<?php
    require_once 'conexao.php';
    if(isset($_POST['botao'])){
        if($_POST['botao'] == 'Inserir'){
            $venda = new Venda;
            $venda->setValores();
            $venda->insereVenda();
        }
    }


    class Venda {
        private $produto;
        private $quantidade;
        private $valorUnitario;
        private $valorTotal;
        private $data;

        function setValores() {
            $this->produto       = $_POST["produto"];
            $this->quantidade    = $_POST["quantidade"];
            $this->valorUnitario = $_POST["valorUnitario"];
            $this->valorTotal    = $this->quantidade*$this->valorUnitario;
        }

        public function getProduto(){
            return $this->produto;
        }

        public function getQuantidade(){
            return $this->quantidade;
        }

        public function getValorTotal(){
            return $this->valorTotal;
        }

        public function getValorUnitario(){
            return $this->valorUnitario;
        }

        public function getData(){
            return $this->valorUnitario;
        }

        public function insereVenda(){
            $sql = 'INSERT INTO `venda`(`produto`, `quantidade`, `valorUnitario`, `valorTotal`, `data`) 
                    VALUES ('.$this->getproduto().','.$this->getquantidade().','.$this->getValorUnitario().','.$this->getvalorTotal().', "'.date("Y-m-d").'")';
            $con = new Conexao;
            $con->setConexao();
            $result = $con->query($sql);
            //echo $sql;
            header('Location: form-venda.php');
        }
    }
?>